import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ApiService } from '../api.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  model:any={}
  submitted=false;
  constructor(private _router:Router,private api:ApiService) { }

  ngOnInit(): void {
  }

  validate(f:any){
    this.submitted=true;
    if(f.valid){
      this.api.validate(f.value.userid,f.value.pwd).subscribe(resp=>{
        console.log(resp)      
        alert("Login successfull")
        sessionStorage.setItem("id",resp.id);
        sessionStorage.setItem("userid",resp.userid)
        sessionStorage.setItem("uname",resp.uname)            
        this._router.navigate(['dashboard']);      
      },
      error=>{
        alert("Invalid username or password")
      })
    }
  }
}
