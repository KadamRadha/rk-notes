import { HttpClient, HttpErrorResponse, HttpResponse } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, Subject } from 'rxjs';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  logoutSubject = new Subject<boolean>();
	loginSubject = new Subject<any>();
	private host = environment.apiUrl;
	private authToken: any;

	constructor(private httpClient: HttpClient) { }

	signup(userSignup: any) {
		return this.httpClient.post<any>(`${this.host}`, userSignup);
	}

	login(userLogin: any): Observable<HttpResponse<any> | HttpErrorResponse> {
		return this.httpClient.post<any>(`${this.host}/validate`, userLogin, { observe: 'response' });
	}

	logout(): void {
		this.authToken = null;
		localStorage.removeItem('authUser');
		localStorage.removeItem('authToken');
		this.logoutSubject.next(true);
	}

	storeTokenInCache(authToken: string): void {
		if (authToken != null && authToken != '') {
			this.authToken = authToken;
			localStorage.setItem('authToken', authToken);
		}
	}

	loadAuthTokenFromCache(): void {
		this.authToken = localStorage.getItem('authToken');
	}

	getAuthTokenFromCache(): any {
		return localStorage.getItem('authToken');
	}

	getAuthUserFromCache() {
		return JSON.parse(localStorage.getItem('authUser'));
	}

	getAuthUserId(): number {
		return this.getAuthUserFromCache().id;
	}

	isUserLoggedIn(): boolean {
		this.loadAuthTokenFromCache();

		if (this.authToken != null && this.authToken != '') {
			return true;
		}

		this.logout();
		return false;
	}
}
