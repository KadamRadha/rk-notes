import { Component, OnInit, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { ApiService } from '../api.service';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {

  @ViewChild('closebutton') closebutton:any;

  model:any={}
  tweets:any[]=[]
  flist:any[]=[]
  fslist:any[]=[]
  fcount:any=0
  fscount:any=0
  uname:any="";
  constructor(private api:ApiService,private _router:Router) { }

  ngOnInit(): void {
    this.load_tweets()
    this.load_followers()
    this.load_followings()
    this.uname=sessionStorage.getItem("uname")
  }

  createTweet(f:any) {
    let id=sessionStorage.getItem("id")||"";
    let tweet={'content':f.value.content,'userid':parseInt(id)}        
    this.api.createTweet(tweet).subscribe(resp=>{
      console.log(resp); 
      this.load_tweets()
      this.closebutton.nativeElement.click(); 
      this.model.content="";    
    });
  }

  load_tweets(){
    let userid=sessionStorage.getItem("id")
    return this.api.getallTweets(userid).subscribe(resp=>{
      console.log(resp)
      this.tweets=resp            
    });
  }

  updateData(){
    this.load_tweets()
    this.load_followers()
    this.load_followings()
  }
  
  load_followers(){
    let id=sessionStorage.getItem("id")||"";
    return this.api.getFollowers(id).subscribe(resp=>{
      console.log(resp)
      this.flist=resp 
      this.fcount=this.flist.length;           
    });
  }

  load_followings(){
    let id=sessionStorage.getItem("id")||"";
    return this.api.getFollowings(id).subscribe(resp=>{
      console.log(resp)
      this.fslist=resp        
    this.fscount=this.fslist.length;          
    });
  }

  logout(){
    sessionStorage.clear();
    this._router.navigate(['/'])
  }
}
