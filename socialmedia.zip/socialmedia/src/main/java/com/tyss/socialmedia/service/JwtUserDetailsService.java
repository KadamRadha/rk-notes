package com.tyss.socialmedia.service;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.tyss.socialmedia.entity.SocialMediaUser;
import com.tyss.socialmedia.repository.SocialMediaRepository;

@Service
public class JwtUserDetailsService implements UserDetailsService {

	@Autowired
	SocialMediaRepository socialMediaRepository;

	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		SocialMediaUser socialMediaUser = null;

		String value = ".";
		if (username.contains(value)) {
			socialMediaUser = socialMediaRepository.findByEmail(username);
		} else {
			socialMediaUser = socialMediaRepository.findByMobileNumber(username);
		}

		if (socialMediaUser == null) {
			throw new UsernameNotFoundException("User not found for this username: " + username);
		}
		return new User(socialMediaUser.getEmail(), socialMediaUser.getPassword(), new ArrayList<>());
	}
}
