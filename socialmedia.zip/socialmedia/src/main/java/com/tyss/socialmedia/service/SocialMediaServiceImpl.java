package com.tyss.socialmedia.service;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.List;

import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import com.tyss.socialmedia.entity.Following;
import com.tyss.socialmedia.entity.Login;
import com.tyss.socialmedia.entity.SocialMediaImages;
import com.tyss.socialmedia.entity.SocialMediaUser;
import com.tyss.socialmedia.pojo.DataPojo;
import com.tyss.socialmedia.pojo.FollowingPojo;
import com.tyss.socialmedia.pojo.SocialMediaFollowers;
import com.tyss.socialmedia.pojo.SocialMediaFollowing;
import com.tyss.socialmedia.pojo.SocialMediaImagePojo;
import com.tyss.socialmedia.pojo.SocialMediaUserPojo;
import com.tyss.socialmedia.repository.SocialMediaRepository;

import net.bytebuddy.utility.RandomString;

@Transactional
@Service
public class SocialMediaServiceImpl implements SocialMediaUserService {

	@Autowired
	SocialMediaRepository socialMediaRepository;

	@Autowired
	private PasswordEncoder passwordEncoder;

	@Autowired
	private JavaMailSender javaMailSender;

	@Override
	public SocialMediaUser socialMediaUserCreation(SocialMediaUserPojo socialMediaUserPojo) {
		SocialMediaUser socialMediaUser = new SocialMediaUser();
		socialMediaUser.setPassword(passwordEncoder.encode(socialMediaUserPojo.getPassword()));
		socialMediaUser.setEmail(socialMediaUserPojo.getEmail());
		socialMediaUser.setUserId(socialMediaUserPojo.getUserId());
		socialMediaUser.setFirstName(socialMediaUserPojo.getFirstName());
		socialMediaUser.setGender(socialMediaUserPojo.getGender());
		socialMediaUser.setLastName(socialMediaUserPojo.getLastName());
		socialMediaUser.setMobileNumber(socialMediaUserPojo.getMobileNumber());
		socialMediaUser.setFullName(socialMediaUserPojo.getFullName());
		socialMediaUser.setUserName(socialMediaUserPojo.getUserName());
		socialMediaUser.setFullName(socialMediaUserPojo.getFirstName() + " " + socialMediaUserPojo.getLastName());
		socialMediaUser.setEnabled(false);
		System.out.println(socialMediaUser.getFullName());
		String randomCode = RandomString.make(64);
		socialMediaUser.setVerficationCode(randomCode);
		return socialMediaRepository.save(socialMediaUser);
	}

	@Override
	public void sendVerificationEmail(SocialMediaUserPojo socialMediaUser, String siteURL)
			throws UnsupportedEncodingException, MessagingException {
		System.out.println(socialMediaUser);
		String subject = "Please verify your registration";
		String senderName = "Social Media Provider";
		String mailContent = "<p> Dear " + socialMediaUser.getFullName() + ",</p>";
		mailContent += "<p>Please Click the link below to verify to your registration</p>";
		String verifyURL = siteURL + "/verification?code=" + socialMediaUser.getVerficationCode();
		mailContent += "<h3><a=\"href=http://localhost:8091/" + verifyURL + "\">VERIFY</a></h3>";
		mailContent += "<p>Thank you!!<br> The Social Media Provider</p>";
		MimeMessage mimeMessage = javaMailSender.createMimeMessage();
		MimeMessageHelper mimeMessageHelper = new MimeMessageHelper(mimeMessage);
		mimeMessageHelper.setFrom("shrinivasdeveloper432@gmail.com", senderName);
		System.out.println(socialMediaUser.getEmail());
		mimeMessageHelper.setTo("shreenivastikare@gmail.com");
		mimeMessageHelper.setSubject(subject);
		mimeMessageHelper.setText(mailContent, true);

		javaMailSender.send(mimeMessage);

	}

	@Override
	public boolean verify(String verificationCode) {
		SocialMediaUser socialMediaUser = socialMediaRepository.findByVerficationCode(verificationCode);

		if (socialMediaUser == null || socialMediaUser.isEnabled()) {
			return false;
		} else {
			socialMediaUser.setVerficationCode(null);
			socialMediaRepository.enable(socialMediaUser.getUserId());
			socialMediaRepository.save(socialMediaUser);
			return true;
		}
	}

	@Override
	public String login(Login login) {
		SocialMediaUser socialMediaUser = new SocialMediaUser();
		SocialMediaUser findByEmail = socialMediaRepository.findByEmail(login.getEmail());
		if (findByEmail.equals(login.getEmail())
				&& passwordEncoder.matches(socialMediaUser.getPassword(), login.getPassword())) {
			return "Login Successfull";
		}
		return "not successfull";
	}

	@Override
	public SocialMediaImagePojo getImage(String email) {
		SocialMediaImagePojo socialMediaImagePojo = new SocialMediaImagePojo();
		SocialMediaUser findByEmail = socialMediaRepository.findByEmail(email);
		BeanUtils.copyProperties(findByEmail, socialMediaImagePojo);
		return socialMediaImagePojo;

	}

	@Override
	public String addImage(String email, MultipartFile[] file) {
		SocialMediaUser findByEmail = socialMediaRepository.findByEmail(email);
		if (findByEmail != null) {
			List<SocialMediaImages> medias = findByEmail.getMedia();
			for (MultipartFile mediaVariation : file) {
				try {
					SocialMediaImages mediaVariMedia = new SocialMediaImages();
					mediaVariMedia.setMediaFile(mediaVariation.getBytes());
					medias.add(mediaVariMedia);

				} catch (IOException e) {
					e.printStackTrace();
				}
			}
			findByEmail.setMedia(medias);
			socialMediaRepository.save(findByEmail);

		}
		return "saved";
	}

	@Override
	public SocialMediaUser followings(DataPojo dataPojo) {
		SocialMediaUser findByEmail = socialMediaRepository.findByEmail(dataPojo.getEmail());
		List<Following> followings1 = new ArrayList<>();
		List<FollowingPojo> followings = dataPojo.getFollowings();
		for (FollowingPojo following : followings) {
			Following following2 = new Following();
			following2.setFollowingName(following.getFollowingName());
			followings1.add(following2);
		}
		findByEmail.setFollowings(followings1);
		return findByEmail;

	}

	@Override
	public SocialMediaFollowing getFollowing(String email) {
		SocialMediaFollowing socialMediaFollowing = new SocialMediaFollowing();
		SocialMediaUser findByEmail = socialMediaRepository.findByEmail(email);
		BeanUtils.copyProperties(findByEmail, socialMediaFollowing);
		return socialMediaFollowing;
	}

	@Override
	public SocialMediaFollowers getFollowers(String email) {
		SocialMediaFollowers socialMediaFollowers = new SocialMediaFollowers();
		SocialMediaUser findByEmail = socialMediaRepository.findByEmail(email);
		BeanUtils.copyProperties(findByEmail, socialMediaFollowers);
		return socialMediaFollowers;
	}
}
