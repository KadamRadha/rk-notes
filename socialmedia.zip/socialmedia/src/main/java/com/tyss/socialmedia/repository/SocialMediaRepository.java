package com.tyss.socialmedia.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.tyss.socialmedia.entity.SocialMediaUser;

@Repository
public interface SocialMediaRepository
		extends JpaRepository<SocialMediaUser, Integer>{

//	@Query("select socialMediaUser from SocialMediaUser socialMediaUser where socialMediaUser.email=?1 ")
	public SocialMediaUser findByEmail(String email);
	

	@Query("update SocialMediaUser socialMediaUser SET socialMediaUser.enabled=true where socialMediaUser.userId=?1 ")
	@Modifying
	public void enable(int userId);

	@Query("SELECT socialMediaUser FROM  SocialMediaUser socialMediaUser WHERE socialMediaUser.verficationCode = ?1")
	public SocialMediaUser findByVerficationCode(String verficationCode);

	public SocialMediaUser findByMobileNumber(String mobileNumber);

	public SocialMediaUser findAllByEmail(String email);
}
