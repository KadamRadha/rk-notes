package com.tyss.socialmedia.service;

import java.io.UnsupportedEncodingException;

import javax.mail.MessagingException;

import org.springframework.web.multipart.MultipartFile;

import com.tyss.socialmedia.entity.Login;
import com.tyss.socialmedia.entity.SocialMediaUser;
import com.tyss.socialmedia.pojo.DataPojo;
import com.tyss.socialmedia.pojo.SocialMediaFollowers;
import com.tyss.socialmedia.pojo.SocialMediaFollowing;
import com.tyss.socialmedia.pojo.SocialMediaImagePojo;
import com.tyss.socialmedia.pojo.SocialMediaUserPojo;

public interface SocialMediaUserService {

	public SocialMediaUser socialMediaUserCreation(SocialMediaUserPojo socialMediaUserPojo);

	public void sendVerificationEmail(SocialMediaUserPojo socialMediaUser, String siteURL)
			throws UnsupportedEncodingException, MessagingException;

	public boolean verify(String verificationCode);

	public String addImage(String email, MultipartFile[] file);

	public SocialMediaImagePojo getImage(String email);

	public String login(Login login);

	public SocialMediaUser followings(DataPojo dataPojo);

	public SocialMediaFollowing getFollowing(String email);

	public SocialMediaFollowers getFollowers(String email);

}
