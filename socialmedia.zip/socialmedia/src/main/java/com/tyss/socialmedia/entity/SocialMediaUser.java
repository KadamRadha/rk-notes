package com.tyss.socialmedia.entity;

import java.io.Serializable;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;

import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.Data;

@Data
@Entity
public class SocialMediaUser implements Serializable {

	/**
	 * @author SHREENIVAS
	 */
	private static final long serialVersionUID = 1L;

	@Id
	private int userId;

	private String userName;

	private String password;

	private String firstName;

	private String lastName;

	@JsonIgnore
	private String fullName = firstName + " " + lastName;

	private long mobileNumber;

	private String email;

	private String gender;

	@JsonIgnore
	private boolean enabled;

	@JsonIgnore
	private String verficationCode;

	
	@OneToMany(cascade = CascadeType.ALL)
	@JoinColumn(name = "userId")
	private List<SocialMediaImages> media;
	
	@OneToMany(cascade = CascadeType.ALL)
	@JoinColumn(name = "userId")
	private List<Following> followings;

	@OneToMany(cascade = CascadeType.ALL)
	@JoinColumn(name = "userId")
	private List<Followers> followers;

}
