package com.tyss.socialmedia.controller;

import java.io.UnsupportedEncodingException;

import javax.mail.MessagingException;
import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.query.Param;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.tyss.socialmedia.entity.Login;
import com.tyss.socialmedia.entity.SocialMediaUser;
import com.tyss.socialmedia.pojo.DataPojo;
import com.tyss.socialmedia.pojo.SocialMediaFollowers;
import com.tyss.socialmedia.pojo.SocialMediaFollowing;
import com.tyss.socialmedia.pojo.SocialMediaImagePojo;
import com.tyss.socialmedia.pojo.SocialMediaUserPojo;
import com.tyss.socialmedia.service.SocialMediaUserService;
import com.tyss.socialmedia.utility.Utility;

@RestController
public class SocialMediaController {

	@Autowired
	private SocialMediaUserService socialMediaUserService;

	@PostMapping("/save")
	public String createSocialMediaAccount(@RequestBody SocialMediaUserPojo socialMediaUserPojo, Model model,
			HttpServletRequest httpServletRequest) throws UnsupportedEncodingException, MessagingException {
		socialMediaUserService.socialMediaUserCreation(socialMediaUserPojo);
		String siteURL = Utility.getSiteURL(httpServletRequest);
		socialMediaUserService.sendVerificationEmail(socialMediaUserPojo, siteURL);
		model.addAttribute("pageTitle", "Registeration Successfull");
		return "register/register_success";
	}

	@GetMapping("/verify")
	public String verifyAccount(@Param("verificationCode") String verificationCode, Model model) {
		boolean verified = socialMediaUserService.verify(verificationCode);

		String pageTitle = verified ? "verified successfull" : "verified failed";
		model.addAttribute("pageTitle", pageTitle);
		return "registerd/" + (verified ? "verify_success" : "verify_fail");
	}

	@PostMapping("/login")

	public String loginSocialMediaAccount(@RequestBody Login login) {
		String socialMediaUser2 = socialMediaUserService.login(login);
		if (socialMediaUser2 != null) {
			return "login Successfull";
		}
		return "not successfull";
	}

	@PostMapping(value = { "/addImage/{email}" }, consumes = { MediaType.MULTIPART_FORM_DATA_VALUE })
	public ResponseEntity<Object> saveImage(@PathVariable String email,
			@RequestParam("variationMedias") MultipartFile[] variationMedias)
			throws JsonMappingException, JsonProcessingException {
		String addImage = socialMediaUserService.addImage(email, variationMedias);
		if (addImage != null) {
			return new ResponseEntity<>("add", HttpStatus.OK);
		} else {

			return new ResponseEntity<>("not added", HttpStatus.OK);
		}

	}

	@PostMapping("/getImage/{email}")
	public SocialMediaImagePojo saveFollowing(@RequestBody String email) {
		return socialMediaUserService.getImage(email);
	}

	@PostMapping("/saveFollowing")
	public SocialMediaUser saveFollowing(@RequestBody DataPojo dataPojo) {
		return socialMediaUserService.followings(dataPojo);
	}

	@GetMapping("/getFollowing/{email}")
	public SocialMediaFollowing getData(@PathVariable("email") String email) {
		return socialMediaUserService.getFollowing(email);

	}

	@GetMapping("/getFollowers/{email}")
	public SocialMediaFollowers getDatafollowers(@PathVariable("email") String email) {
		return socialMediaUserService.getFollowers(email);

	}
}