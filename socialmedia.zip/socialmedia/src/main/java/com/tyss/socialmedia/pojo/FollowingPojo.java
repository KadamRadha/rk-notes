package com.tyss.socialmedia.pojo;

import lombok.Data;

@Data
public class FollowingPojo {

private int followingId;
	
	private String followingName;
}
