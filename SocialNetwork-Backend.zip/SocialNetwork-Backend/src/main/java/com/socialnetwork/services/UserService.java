package com.socialnetwork.services;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.socialnetwork.models.User;
import com.socialnetwork.repos.UserRepository;
import com.socialnetwork.utils.StorageService;

@Service
public class UserService {

	@Autowired private UserRepository repo;
	@Autowired private PasswordEncoder passwordEncoder;
	@Autowired private StorageService storage;
	
	public void saveuser(User user,MultipartFile profilepic) {
		String filename=storage.store(profilepic);
		user.setPhoto(filename);
		String pwd=passwordEncoder.encode(user.getPwd());
		user.setPwd(pwd);
		repo.save(user);
	}
	
	public Optional<User> findByUserId(String userid) {
		return repo.findByUserid(userid);
	}
		
}
