package com.vms.exception;

public class RecordNotFound extends Exception{
	public RecordNotFound(String message) {
		super(message);
	}
}
