package com.vms.controller;

import java.time.LocalDate;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.vms.entity.VaccineInventory;
import com.vms.exception.RecordNotFound;
import com.vms.service.VaccineInventoryService;

@CrossOrigin
@RestController
@RequestMapping("/vms-vaccineInventory")

public class VaccineInventoryController {
	
	@Autowired
	VaccineInventoryService vaccineInventoryService;
	
	@PostMapping
	public VaccineInventory addVaccineInventory(@RequestBody VaccineInventory vaccineInventory) throws RecordNotFound{
		System.out.println(vaccineInventory);
		return vaccineInventoryService.addVaccineInventory(vaccineInventory);
	}
	
	@PutMapping("{id}")
	public VaccineInventory updateVaccineInventory(@PathVariable("id")int id,@RequestBody VaccineInventory vaccineInventory) throws RecordNotFound{
		return vaccineInventoryService.updateVaccineInventory(vaccineInventory);
	}
	
	@DeleteMapping("{id}")
	public ResponseEntity<?> deleteVaccineInventory(@PathVariable("id")int id) throws RecordNotFound{
		vaccineInventoryService.deleteVaccineInventory(id);
		return ResponseEntity.ok("Vaccine inventory deleted successfully");
	}
	
	@GetMapping("/getVaccineRegistrationByDare/{date}")
	public VaccineInventory getVaccineRegistrationByDare(@RequestParam("localDate") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE)LocalDate date) throws RecordNotFound{
		return vaccineInventoryService.getVaccineRegistrationByDare(date);
	}
	
	@GetMapping
	public List<VaccineInventory> getAllVaccineInventories() throws RecordNotFound{
		return vaccineInventoryService.getAllVaccineInventories();
	}
	
	@GetMapping("/getVaccineInventoryByCenter/{centerId}")
	public VaccineInventory getVaccineInventoryByCenter(@PathVariable int centerId) throws RecordNotFound{
		return vaccineInventoryService.getVaccineInventoryByCenter(centerId);
	}


}



















