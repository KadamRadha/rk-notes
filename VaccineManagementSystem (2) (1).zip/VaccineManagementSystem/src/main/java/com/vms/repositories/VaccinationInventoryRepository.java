package com.vms.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.vms.entity.VaccineCenter;
import com.vms.entity.VaccineInventory;

@Repository
public interface VaccinationInventoryRepository  extends JpaRepository< VaccineInventory,Integer>{ 

}
