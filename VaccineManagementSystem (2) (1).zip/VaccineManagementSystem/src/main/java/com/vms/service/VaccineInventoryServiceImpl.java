package com.vms.service;

import java.time.LocalDate;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.vms.entity.Member;
import com.vms.entity.VaccineCenter;
import com.vms.entity.VaccineCount;
import com.vms.entity.VaccineInventory;
import com.vms.entity.VaccineRegistration;
import com.vms.exception.RecordNotFound;
import com.vms.repositories.VaccinationInventoryRepository;
import com.vms.repositories.VaccineCountRepository;

@Service("VaccineInventoryService")
public class VaccineInventoryServiceImpl implements VaccineInventoryService{

	@Autowired
	VaccinationInventoryRepository vaccinationInventoryRepository;
	@Autowired
	VaccineCountRepository vcountRepository;
	@Autowired
	VaccineCenterService vccenter;
	
	@Override
	public VaccineInventory addVaccineInventory(VaccineInventory vaccineInventory) throws RecordNotFound {
		vaccineInventory.setVaccineCenter(vccenter.getVaccineCenterById(vaccineInventory.getCenterid()));
		VaccineInventory vcc= vaccinationInventoryRepository.saveAndFlush(vaccineInventory);
		for(VaccineCount vc:vcc.getVaccinesCount()) {
			vc.setVaccineInventory(vcc);
		}
		vcountRepository.saveAll(vaccineInventory.getVaccinesCount());
		return vaccineInventory;
	}


	@Override
	public VaccineInventory updateVaccineInventory(VaccineInventory vaccineInventory) throws RecordNotFound {
		VaccineInventory  bean = null;
		try {
			bean = vaccinationInventoryRepository.findById(vaccineInventory.getVaccInveId()).get();
		}
		catch(Exception e) {
			throw new RecordNotFound("Vaccine Inventory details not found!");
		}
		vaccinationInventoryRepository.saveAndFlush(vaccineInventory);
		return vaccineInventory;
	}

	@Override
	public void deleteVaccineInventory(int id) throws RecordNotFound {
		vaccinationInventoryRepository.deleteById(id);
	}

	@Override
	public VaccineInventory getVaccineRegistrationByDare(LocalDate date) throws RecordNotFound {
		VaccineInventory  bean = null;
		try {
			for(VaccineInventory i : vaccinationInventoryRepository.findAll()) {
				if(i.getDate().equals(date)) {
					bean = i;
				}
			}
		}
		catch(Exception e) {
			throw new RecordNotFound("Vaccine Inventory details not found!");
		}
		return bean;
	}

	@Override
	public List<VaccineInventory> getAllVaccineInventories() throws RecordNotFound {
		return vaccinationInventoryRepository.findAll();
	}

	@Override
	public VaccineInventory getVaccineInventoryByCenter(int centerId) throws RecordNotFound {
		VaccineInventory  bean = null;
		try {
			for(VaccineInventory i : vaccinationInventoryRepository.findAll()) {
				if(i.getVaccineCenter().getVaccCenterId() == centerId) {
					bean = i;
				}
			}
		}
		catch(Exception e) {
			throw new RecordNotFound("Vaccine Inventory details not found!");
		}
		return bean;
	}



}
