package com.vms.service;

import java.time.LocalDate;
import java.util.List;

import com.vms.entity.VaccineInventory;
import com.vms.entity.VaccineRegistration;
import com.vms.exception.RecordNotFound;

public interface VaccineInventoryService {
	
	public VaccineInventory addVaccineInventory(VaccineInventory vaccineInventory) throws RecordNotFound;
	public VaccineInventory updateVaccineInventory(VaccineInventory vaccineInventory) throws RecordNotFound;
	public void deleteVaccineInventory(int id) throws RecordNotFound;
	public VaccineInventory getVaccineRegistrationByDare(LocalDate date) throws RecordNotFound;
	public List<VaccineInventory> getAllVaccineInventories() throws RecordNotFound;
	public VaccineInventory getVaccineInventoryByCenter(int centerId) throws RecordNotFound;

}
